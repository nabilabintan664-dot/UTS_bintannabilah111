package com.example.UTS_bintannabilah111

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    // Jalankan Soal 2 dan 3 di sini
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Bukti Soal 2: Email Form", fontWeight = FontWeight.Bold)
                        EmailForm()

                        Spacer(modifier = Modifier.height(32.dp))

                        Text("Bukti Soal 3: Avatar Badge", fontWeight = FontWeight.Bold)
                        AvatarDenganBadge()
                    }
                }
            }
        }
    }
}

@Composable
fun EmailForm() {
    var email by rememberSaveable { mutableStateOf("") }
    val valid = email.contains("@")

    TextField(
        value = email,
        onValueChange = { email = it },
        label = { Text("Email") }
    )

    if (!valid && email.isNotEmpty()) {
        Text("Email tidak valid", color = Color.Red)
    }
}

@Composable
fun AvatarDenganBadge() {
    Box(modifier = Modifier.size(80.dp)) {
        // Avatar Utama
        Surface(
            modifier = Modifier
                .size(72.dp)
                .align(Alignment.TopStart),
            shape = CircleShape,
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("NP", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }

        // Badge "Aktif"
        Surface(
            modifier = Modifier.align(Alignment.BottomEnd),
            shape = RoundedCornerShape(8.dp),
            color = Color(0xFF4CAF50) // Warna Hijau
        ) {
            Text(
                text = "Aktif",
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                fontSize = 10.sp,
                color = Color.White
            )
        }
    }
}


@Preview(showBackground = true)
@Composable
fun PreviewBukti() {
    MaterialTheme {
        Column(modifier = Modifier.padding(16.dp)) {
            EmailForm()
            Spacer(modifier = Modifier.height(32.dp))
            AvatarDenganBadge()
        }
    }
}