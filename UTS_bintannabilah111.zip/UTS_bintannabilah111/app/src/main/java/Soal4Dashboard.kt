package com.example.UTS_bintannabilah111

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun DashboardAkademik() {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Breakpoint: jika lebar layar >= 600.dp, anggap layar lebar (tablet)
        val isLayarLebar = maxWidth >= 600.dp

        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Dashboard Akademik",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            // Layout Kartu Ringkasan (Adaptif)
            if (isLayarLebar) {
                // Tablet: 3 kolom sejajar (Row)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KartuRingkasan("Tagihan", Modifier.weight(1f))
                    KartuRingkasan("Jadwal", Modifier.weight(1f))
                    KartuRingkasan("Nilai", Modifier.weight(1f))
                }
            } else {
                // Ponsel: 1 kolom menurun (Column)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KartuRingkasan("Tagihan", Modifier.fillMaxWidth())
                    KartuRingkasan("Jadwal", Modifier.fillMaxWidth())
                    KartuRingkasan("Nilai", Modifier.fillMaxWidth())
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Daftar Pengumuman (LazyColumn)
            Text(
                text = "Pengumuman",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f) // Mengisi sisa ruang di bawah
            ) {
                items(3) { index ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Pengumuman ${index + 1}",
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }
        }
    }
}

// Composable bantuan untuk Kartu Ringkasan
@Composable
fun KartuRingkasan(judul: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = judul, style = MaterialTheme.typography.titleMedium)
        }
    }
}

// Preview untuk Melihat Hasil Tanpa Emulator
@Preview(showBackground = true, widthDp = 390) // Simulasi Ponsel
@Composable
fun PreviewDashboardPonsel() {
    MaterialTheme {
        DashboardAkademik()
    }
}

@Preview(showBackground = true, widthDp = 800) // Simulasi Tablet
@Composable
fun PreviewDashboardTablet() {
    MaterialTheme {
        DashboardAkademik()
    }
}